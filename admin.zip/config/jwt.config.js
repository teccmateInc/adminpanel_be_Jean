module.exports = {
  jwtSecret: 'adbdkqdbkabdckasbcxasccqw', // for encoded
  jwtExpires: '5d', // Session is expires in 5 days
};
